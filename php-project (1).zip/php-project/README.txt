Travel Blog – PHP + MySql Project
Welcome to the Travel Blog web application! This project allows users to register, log in, and post travel experiences. It's built using PHP as the backend and MYSQl for data storage.
------------------------------------------------------------------------------------
🚀 Features
User registration and login system

Create, view, edit, and delete travel blog posts

Clean and responsive UI

Secure password hashing

MySQl integration for storing blog posts 
--------------------------------------------------------------------------------------
🛠️ Technologies Used
PHP (Core scripting)

MySQL (Database)

HTML/CSS/Bootstrap (Frontend)

XAMPP or any PHP server
---------------------------------------------------------------------------------------
🔧 Setup Instructions
Install a local server:

Download and install XAMPP or use an alternative like Wamp or Laragon.

Start Apache and MongoDB (or MySQL if you're using that).

Place the project in your web directory:

Extract or clone the project folder into htdocs directory inside XAMPP.
Example path: C:\xampp\htdocs\php-project\

Database setup:

For MySQL , create a database and import project.sql (if available).
----------------------------------------------------------------------------------------
Run the project:

Open browser and navigate to:
👉 http://localhost/php-project/register.php
to register a new user and begin.
