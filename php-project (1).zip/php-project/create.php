<?php
session_start();
include 'db.php';
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $author = $_SESSION['user'];
    $image = $_FILES['image']['name'];

    // Save uploaded file
    move_uploaded_file($_FILES['image']['tmp_name'], 'uploads/' . $image);

    // Insert into DB
    $stmt = $conn->prepare('INSERT INTO blogs (image, title, description, author) VALUES (?, ?, ?, ?)');
    $stmt->bind_param('ssss', $image, $title, $description, $author);
    $stmt->execute();

    header('Location: home.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Travel Story</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container w-50 p-4 mt-5 shadow rounded" style="background-color:#e6f9f2;">
    <h3 class="mb-4 text-center text-primary">Share Your Travel Story ✈️</h3>
    <?php if (!empty($error)): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>
    <form method="post" enctype="multipart/form-data">
        <label><strong>Upload Travel Image</strong></label>
        <input class="form-control mb-3" type="file" name="image" required>

        <label><strong>Destination Title</strong></label>
        <input class="form-control mb-3" type="text" name="title" placeholder="e.g. A Trip to Goa" required>

        <label><strong>Experience Description</strong></label>
        <textarea class="form-control mb-3" name="description" placeholder="Describe your adventure..." rows="5" required></textarea>

        <button class="btn btn-success w-100">Post Travel Story</button>
    </form>
</div>
</body>
</html>
