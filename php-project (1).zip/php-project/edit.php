<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

$id = $_GET['id'];
$result = $conn->query("SELECT * FROM blogs WHERE id=$id");
$blog = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];

    if (!empty($_FILES['image']['name'])) {
        $image = $_FILES['image']['name'];
        $target = "uploads/" . basename($image);
        move_uploaded_file($_FILES['image']['tmp_name'], $target);
        $imageUpdate = ", image='$image'";
    } else {
        $imageUpdate = "";
    }

    $sql = "UPDATE blogs SET title='$title', description='$description' $imageUpdate WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        header("Location: home.php");
        exit;
    } else {
        $error = "Error updating blog: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Blog | Travel Tales</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="home.php">✈️ Travel Blog</a>
</nav>
<div class="container w-50 p-4 mt-5 shadow rounded" style="background-color:#d3e6f2;">
    <h3 class="mb-4 text-center">Edit Your Travel Tale</h3>

    <?php if (!empty($error)): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">
        <div class="mb-3">
            <label><strong>Current Image:</strong></label><br>
            <img src="uploads/<?php echo $blog['image']; ?>" alt="Blog Image" class="img-fluid mb-2 rounded" style="max-height: 200px;">
        </div>
        <input class="form-control mb-3" type="file" name="image">
        <input class="form-control mb-3" type="text" name="title" value="<?php echo htmlspecialchars($blog['title']); ?>" required>
        <textarea class="form-control mb-3" name="description" rows="5" required><?php echo htmlspecialchars($blog['description']); ?></textarea>
        <button class="btn btn-primary w-100" type="submit">Update Blog</button>
    </form>
</div>
</body>
</html>
