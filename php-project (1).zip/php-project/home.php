<?php
include 'db.php';
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

$result = $conn->query("SELECT * FROM blogs ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Travel Stories</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .card-img-top {
            height: 200px;
            object-fit: cover;
        }
    </style>
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="home.php">🌍 Travel Blog</a>
    <div class="ml-auto">
        <a class="btn btn-success mr-2" href="create.php">+ Add Story</a>
        <a class="btn btn-outline-light" href="logout.php">Logout</a>
    </div>
</nav>

<div class="container mt-4">
    <h2 class="mb-4 text-center text-primary">Latest Travel Experiences</h2>
    <div class="row">
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="col-md-4 mb-4">
                <div class="card shadow-sm">
                    <img src="uploads/<?= htmlspecialchars($row['image']) ?>" class="card-img-top" alt="Travel image">
                    <div class="card-body">
                        <h5 class="card-title"><?= htmlspecialchars($row['title']) ?></h5>
                        <p class="card-text"><?= nl2br(htmlspecialchars(substr($row['description'], 0, 100))) ?>...</p>
                        <p class="text-muted small">Shared by: <?= htmlspecialchars($row['author']) ?></p>
                        <a
                            name=""
                            id=""
                            class="btn btn-primary"
                            href="edit.php?id=<?= $row["id"]?>"
                            role="button"
                            >Update</a
                        >
                        <a
                            name=""
                            id=""
                            class="btn btn-danger"
                            href="delete.php?id=<?= $row["id"]?>"
                            role="button"
                            >Delete</a
                        >
                        
                        
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>
</body>
</html>
