<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    
    $stmt = $conn->prepare('SELECT * FROM users WHERE username=?');
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    
    if ($result && password_verify($password, $result['password'])) {
        $_SESSION['user'] = $username;
        header('Location: home.php');
        exit;
    } else {
        $error = 'Invalid login credentials. Please try again.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travel Blog - Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">✈️ Travel Blog</a>
</nav>
<div class="container w-50 p-4 mt-5 shadow rounded" style="background-color:#f2e6d3;">
    <h3 class="mb-4 text-center text-primary">Welcome Back, Traveler</h3>
    
    <?php if (!empty($error)): ?>
        <div class="alert alert-danger text-center"><?= $error ?></div>
    <?php endif; ?>
    
    <form method="post">
        <input class="form-control mb-3" type="text" name="username" placeholder="Username" required>
        <input class="form-control mb-3" type="password" name="password" placeholder="Password" required>
        <button class="btn btn-success w-100" type="submit">Login</button>
    </form>
    <p class="mt-3 text-center">New here? <a href="register.php">Create an account</a></p>
</div>
</body>
</html>
