<?php
include 'db.php';

$name = $email = $password = $confirm_password = "";
$nameErr = $emailErr = $passwordErr = $confirmPasswordErr = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = test_input($_POST["name"]);
    $email = test_input($_POST["email"]);
    $password = test_input($_POST["password"]);
    $confirm_password = test_input($_POST["confirm_password"]);

    if (empty($name) || !preg_match("/^[a-zA-Z ]*$/", $name)) {
        $nameErr = "Valid name is required.";
    }
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailErr = "Valid email is required.";
    }
    if (empty($password) || strlen($password) < 6) {
        $passwordErr = "Password must be at least 6 characters.";
    }
    if ($password !== $confirm_password) {
        $confirmPasswordErr = "Passwords do not match.";
    }

    if (empty($nameErr) && empty($emailErr) && empty($passwordErr) && empty($confirmPasswordErr)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $email, $hashed_password);
        
        if ($stmt->execute()) {
            echo "<div class='alert alert-success text-center'>Registration successful! <a href='login.php'>Login here</a></div>";
        } else {
            echo "<div class='alert alert-danger text-center'>Error: " . $conn->error . "</div>";
        }
        $stmt->close();
    }
}

function test_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travel Blog - Register</title>
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">✈️ Travel Blog</a>
</nav>
<div class="container w-50 p-4 mt-5 shadow rounded" style="background-color:#f2f3f5;">
    <h3 class="mb-4 text-center text-primary">Join the Travel Community</h3>
    <form method="post" novalidate>
        <input class="form-control mb-2" type="text" name="name" placeholder="Full Name" value="<?= htmlspecialchars($name) ?>" required>
        <span style="color: red;"><?= $nameErr ?></span>

        <input class="form-control mb-2" type="email" name="email" placeholder="Email Address" value="<?= htmlspecialchars($email) ?>" required>
        <span style="color: red;"><?= $emailErr ?></span>

        <input class="form-control mb-2" type="password" name="password" placeholder="Create Password" required>
        <span style="color: red;"><?= $passwordErr ?></span>

        <input class="form-control mb-3" type="password" name="confirm_password" placeholder="Confirm Password" required>
        <span style="color: red;"><?= $confirmPasswordErr ?></span>

        <button class="btn btn-success w-100" type="submit">Register</button>
    </form>
    <p class="mt-3 text-center">Already a member? <a href="login.php">Login here</a></p>
</div>
</body>
</html>
